<nav x-data="{ open: false }" class="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
<style>
    .nav-link.text-indigo-600 .nav-underline,
    .nav-link.dark\:text-indigo-400 .nav-underline {
        display: none;
    }
</style>
    {{--Primary Navigation Menu--}}
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> {{--  remember to add in: max-w-7xl  --}}
        <div class="flex justify-between h-16">
            <div class="flex">
                {{--Logo--}}
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('home') }}">
                        {{--<x-application-logo class="block h-9 w-auto fill-current text-gray-800 dark:text-gray-200" />--}}
                        <x-pizza-logo class="h-12 w-12"/>
                    </a>
                </div>

                {{--Navigation Links--}}
                <div class="hidden sm:flex sm:-my-px sm:ms-10 overflow-x-auto sm:max-w-64 md:max-w-xs lg:max-w-lg xl:max-w-3xl whitespace-nowrap space-x-8 scrollbar-hidden"> {{-- hidden space-x-8 sm:-my-px sm:ms-10 sm:flex --}}
                    <!-- Home Link -->
                    <a href="{{ route('home') }}" class="nav-link group inline-flex items-center space-x-2 px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out relative
                        {{ request()->routeIs('home') 
                            ? 'border-indigo-400 dark:border-indigo-600 text-gray-900 dark:text-gray-100' 
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-700' }}">
                        <i class="fas fa-home text-sm group-hover:scale-110 transition-transform duration-200"></i>
                        <span>{{ __('Home') }}</span>
                        @if(!request()->routeIs('home'))
                            <div class="nav-underline absolute bottom-0 left-1 right-1 h-0.5 bg-gray-300 dark:bg-gray-700 transition-all duration-300 scale-x-0 group-hover:scale-x-100 origin-left"></div>
                        @endif
                    </a>

                    <!-- Menu Link -->
                    <a href="{{ route('orders.create') }}" class="nav-link group inline-flex items-center space-x-2 px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out relative
                        {{ request()->routeIs('orders.create') 
                            ? 'border-indigo-400 dark:border-indigo-600 text-gray-900 dark:text-gray-100' 
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-700' }}">
                        <i class="fas fa-pizza-slice text-sm group-hover:scale-110 transition-transform duration-200"></i>
                        <span>{{ __('Menu') }}</span>
                        @if(!request()->routeIs('orders.create'))
                            <div class="nav-underline absolute bottom-0 left-1 right-1 h-0.5 bg-gray-300 dark:bg-gray-700 transition-all duration-300 scale-x-0 group-hover:scale-x-100 origin-left"></div>
                        @endif
                    </a>

                    <!-- Cart Link -->
                    <a href="{{ route('cart.index') }}" class="nav-link group inline-flex items-center space-x-2 px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out relative
                        {{ request()->routeIs('cart.*') 
                            ? 'border-indigo-400 dark:border-indigo-600 text-gray-900 dark:text-gray-100' 
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-700' }}">
                        <i class="fas fa-shopping-cart text-sm group-hover:scale-110 transition-transform duration-200"></i>
                        <span>{{ __('Cart') }}</span>
                        @if(!request()->routeIs('cart.*'))
                            <div class="nav-underline absolute bottom-0 left-1 right-1 h-0.5 bg-gray-300 dark:bg-gray-700 transition-all duration-300 scale-x-0 group-hover:scale-x-100 origin-left"></div>
                        @endif
                    </a>

                    <!-- Orders Link -->
                    <a href="{{ route('history.index') }}" class="nav-link group inline-flex items-center space-x-2 px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out relative
                        {{ request()->routeIs('history.index') 
                            ? 'border-indigo-400 dark:border-indigo-600 text-gray-900 dark:text-gray-100' 
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-700' }}">
                        <i class="fas fa-receipt text-sm group-hover:scale-110 transition-transform duration-200"></i>
                        <span>{{ __('Orders') }}</span>
                        @if(!request()->routeIs('history.index'))
                            <div class="nav-underline absolute bottom-0 left-1 right-1 h-0.5 bg-gray-300 dark:bg-gray-700 transition-all duration-300 scale-x-0 group-hover:scale-x-100 origin-left"></div>
                        @endif
                    </a>

                    <!-- Admin Link -->
                    <a href="{{ route('admin.products.index') }}" class="nav-link group inline-flex items-center space-x-2 px-1 pt-1 border-b-2 text-sm font-medium leading-5 transition duration-150 ease-in-out relative
                        {{ request()->routeIs('admin.*') 
                            ? 'border-indigo-400 dark:border-indigo-600 text-gray-900 dark:text-gray-100' 
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-700' }}">
                        <i class="fas fa-cog text-sm group-hover:scale-110 transition-transform duration-200"></i>
                        <span>{{ __('Admin') }}</span>
                        @if(!request()->routeIs('admin.*'))
                            <div class="nav-underline absolute bottom-0 left-1 right-1 h-0.5 bg-gray-300 dark:bg-gray-700 transition-all duration-300 scale-x-0 group-hover:scale-x-100 origin-left"></div>
                        @endif
                    </a>
{{--                    <x-nav-link :href="route('orderItems.index')" :active="request()->routeIs('orderItems.index')">--}}
{{--                        {{ __('Order Items') }}--}}
{{--                    </x-nav-link>--}}
{{--                    <x-nav-link :href="route('pizzaOrderItemDetails.index')" :active="request()->routeIs('pizzaOrderItemDetails.index')">--}}
{{--                        {{ __('Pizza Order Item Details') }}--}}
{{--                    </x-nav-link>--}}
{{--                    <x-nav-link :href="route('pizzaOrderItemToppings.index')" :active="request()->routeIs('pizzaOrderItemToppings.index')">--}}
{{--                        {{ __('Pizza Order Item Toppings') }}--}}
{{--                    </x-nav-link>--}}
                    {{--Guest navigation links - only show for anonymous users--}}
                    @guest
                        {{--You can add additional guest navigation links here if needed--}}
                        {{--Example: About, Services, Contact, etc.--}}
                    @endguest
                </div>
            </div>

            {{--Right side navigation: Authentication dependent--}}
            @auth
            {{--Settings Dropdown for authenticated users--}}
            <div class="hidden sm:flex sm:items-center sm:ms-6">
                {{--<a class="mr-4 inline-block px-5 py-1.5 dark:text-[#EDEDEC] border-[#19140035] hover:border-[#1915014a] border text-[#1b1b18] dark:border-[#3E3E3A] dark:hover:border-[#62605b] rounded-sm text-sm leading-normal transition-colors duration-150"
                   href="{{ route('cart.index') }}">{{ __('Cart') }}
                </a>--}}
                <form action="{{ route('cart.clear') }}" method="POST">
                    @csrf
                    <button type="submit" class="inline-flex items-center me-4 px-4 py-2 bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 hover:border-gray-300 dark:hover:border-gray-500 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                        Clear Cart
                    </button>
                </form>
                <x-dropdown align="right" width="48">
                    <x-slot name="trigger">
                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-full text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 hover:text-gray-700 dark:hover:text-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-red-400 transition-all duration-200 ease-in-out shadow-sm hover:shadow-md">
                            <!-- Profile Picture -->
                            <div class="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center mr-2 ring-2 ring-white dark:ring-gray-800">
                                @if(Auth::user()->profile_photo_path && file_exists(public_path(Auth::user()->profile_photo_path)))
                                    <img src="{{ asset(Auth::user()->profile_photo_path) }}" 
                                         alt="{{ Auth::user()->name }}" 
                                         class="w-full h-full object-cover">
                                @else
                                    <span class="text-white text-xs font-bold">
                                        {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                                    </span>
                                @endif
                            </div>
                            
                            <!-- Name with subtle styling -->
                            <div class="font-medium">{{ Auth::user()->name }}</div>

                            <!-- Dropdown Arrow -->
                            <div class="ml-2">
                                <svg class="fill-current h-4 w-4 transition-transform duration-200" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </button>
                    </x-slot>

                    <x-slot name="content">
                        <x-dropdown-link :href="route('profile.edit')">
                            {{ __('Profile') }}
                        </x-dropdown-link>

                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    </x-slot>
                </x-dropdown>
            </div>
            @else
            <!-- Guest authentication links: show Login and Register for anonymous users -->
            <div class="hidden sm:flex sm:items-center sm:ms-6 space-x-3">
                <!-- Clear Cart Button for Guests -->
                <form action="{{ route('cart.clear') }}" method="POST">
                    @csrf
                    <button type="submit" class="inline-flex items-center px-4 py-2 bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 hover:border-gray-300 dark:hover:border-gray-500 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                        Clear Cart
                    </button>
                </form>

                <!-- Login Link -->
                <a
                    href="{{ route('login') }}"
                    class="inline-flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 border border-transparent hover:border-gray-200 dark:hover:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg text-sm font-medium transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
                >
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path>
                    </svg>
                    {{ __('Log in') }}
                </a>

                <!-- Register Link -->
                <a
                    href="{{ route('register') }}"
                    class="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white border border-transparent rounded-lg text-sm font-medium transition-all duration-200 ease-in-out shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                    </svg>
                    {{ __('Register') }}
                </a>
            </div>
            @endauth

            <!-- Hamburger -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-900 focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    {{--Responsive Navigation Menu--}}
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
            <x-responsive-nav-link :href="route('home')" :active="request()->routeIs('home')">
                {{ __('Home') }}
            </x-responsive-nav-link>
            {{--
            <x-responsive-nav-link :href="route('pizzas.index')" :active="request()->routeIs('pizzas.*')">
                {{ __('Pizzas') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('pizzaSizes.index')" :active="request()->routeIs('pizzaSizes.index')">
                {{ __('Pizza Sizes') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('crusts.index')" :active="request()->routeIs('crusts.index')">
                {{ __('Crusts') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('products.index')" :active="request()->routeIs('products.index')">
                {{ __('Products') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('toppings.index')" :active="request()->routeIs('toppings.index')">
                {{ __('Toppings') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('pizzaSizePrices.index')" :active="request()->routeIs('pizzaSizePrices.index')">
                {{ __('Pizza Size Prices') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('crustPriceAdditions.index')" :active="request()->routeIs('crustPriceAdditions.index')">
                {{ __('Crust Price Additions') }}
            </x-responsive-nav-link>
            --}}
            <x-responsive-nav-link :href="route('orders.create')" :active="request()->routeIs('orders.create')">
                {{ __('Menu') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('cart.index')" :active="request()->routeIs('cart.*')">
                {{ __('Cart') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('history.index')" :active="request()->routeIs('history.index')">
                {{ __('Orders') }}
            </x-responsive-nav-link>
            <x-responsive-nav-link :href="route('admin.products.index')">
                {{ __('Admin') }}
            </x-responsive-nav-link>
{{--            <x-responsive-nav-link :href="route('orderItems.index')" :active="request()->routeIs('orderItems.index')">--}}
{{--                {{ __('Order Items') }}--}}
{{--            </x-responsive-nav-link>--}}
{{--            <x-responsive-nav-link :href="route('pizzaOrderItemDetails.index')" :active="request()->routeIs('pizzaOrderItemDetails.index')">--}}
{{--                {{ __('Pizza Order Item Details') }}--}}
{{--            </x-responsive-nav-link>--}}
{{--            <x-responsive-nav-link :href="route('pizzaOrderItemToppings.index')" :active="request()->routeIs('pizzaOrderItemToppings.index')">--}}
{{--                {{ __('Pizza Order Item Toppings') }}--}}
{{--            </x-responsive-nav-link>--}}

            <!-- Additional guest navigation links can be added here for mobile -->
            @guest
                <!-- Example: You can add other public pages here if needed -->
            @endguest

        </div>
        @auth
        <!-- Responsive Settings Options for authenticated users -->
        <div class="pt-4 pb-1 border-t border-gray-200 dark:border-gray-600">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800 dark:text-gray-200">{{ Auth::user()->name }}</div>
                <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('profile.edit')">
                    {{ __('Profile') }}
                </x-responsive-nav-link>

                <!-- Authentication -->
                <form method="POST" action="{{ route('logout') }}">
                    @csrf

                    <x-responsive-nav-link :href="route('logout')"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();">
                        {{ __('Log Out') }}
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
        @else
        <!-- Mobile authentication links for guest users -->
        <div class="pt-4 pb-1 border-t border-gray-200 dark:border-gray-600">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800 dark:text-gray-200">Guest</div>
                <div class="font-medium text-sm text-gray-500">Welcome to the Pizza Shop</div>
            </div>
            <div class="mt-3 space-y-1">
                <!-- Mobile Login Link -->
                <a
                    href="{{ route('login') }}"
                    class="block w-full ps-3 pe-4 py-2 border-l-4 border-transparent text-start text-base font-medium text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-600 focus:outline-none focus:text-gray-800 dark:focus:text-gray-200 focus:bg-gray-50 dark:focus:bg-gray-700 focus:border-gray-300 dark:focus:border-gray-600 transition duration-150 ease-in-out"
                >
                    {{ __('Log in') }}
                </a>

                <!-- Mobile Register Link -->
                <a
                    href="{{ route('register') }}"
                    class="block w-full ps-3 pe-4 py-2 border-l-4 border-transparent text-start text-base font-medium text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-600 focus:outline-none focus:text-gray-800 dark:focus:text-gray-200 focus:bg-gray-50 dark:focus:bg-gray-700 focus:border-gray-300 dark:focus:border-gray-600 transition duration-150 ease-in-out"
                >
                    {{ __('Register') }}
                </a>
            </div>
        </div>
        @endauth
    </div>
</nav>
